// create variable

const inputBox = document.getElementById("input-Box");

const listContainer = document.getElementById("list-Container");

let editItem = null;

// function

function addTask() {
 
    if (inputBox.value == '') {
        alert("You must write something!");
    }

    else {
        let li = document.createElement("li");
        li.innerHTML = `<span class="task-text">${inputBox.value}</span>`;

        let spanActions = document.createElement("div");
        spanActions.className = "actions";

        let spanEdit = document.createElement("span");
        spanEdit.innerHTML = '<i class="fa fa-edit"></i>';
        spanEdit.addEventListener('click', function () {
        openEditModal(li);
     
        });
        spanActions.appendChild(spanEdit);

         // cancle button

        let spanDelete = document.createElement("span");
        spanDelete.innerHTML = '<i class="fa fa-times"></i>';
        spanActions.appendChild(spanDelete);

        li.appendChild(spanActions);
        listContainer.appendChild(li);
    }

    inputBox.value = "";
    saveData();
}

// clicking button funcionality

listContainer.addEventListener("click", function (e) 
{
    if (e.target.tagName === "LI") {
        e.target.classList.toggle("checked");
        saveData();
    }
    
    else if (e.target.tagName === "SPAN" || e.target.tagName === "I") {
        if (e.target.closest("span").innerHTML.includes("times")) {
            e.target.closest("li").remove();
            saveData();
        }
    }
}, false);

// for saving data on browser

function saveData() {
    localStorage.setItem("data", listContainer.innerHTML);
}

// showing data on browser

function showTask() {
    listContainer.innerHTML = localStorage.getItem("data");
}

// for update the option

function openEditModal(item) {
    editItem = item;
    document.getElementById("edit-Box").value = item.querySelector(".task-text").textContent;
    document.getElementById("editModal").style.display = "block";
}

// closing the update menu

function closeEditModal() {
    document.getElementById("editModal").style.display = "none";
}


function submitEdit() {
    if (editItem) {
        editItem.querySelector(".task-text").textContent = document.getElementById("edit-Box").value;
        closeEditModal();
        saveData();
    }
}

showTask();


// script end